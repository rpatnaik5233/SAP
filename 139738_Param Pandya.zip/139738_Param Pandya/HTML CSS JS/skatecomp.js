function submitFormDetails()
{
	alert("All data entered successfully");
	
	var fullname = document.getElementById("nameID").value;
	var type = document.getElementById("skateBeg").value;
	var dob = document.getElementById("dateID").value;
	var date1 = new Date();
    var dobDate = new Date(dob);
    var age = date1.getFullYear() - dobDate.getFullYear();
	var ageGroup;
	var fees;
	
	if(age < 11)
	{
			ageGroup = "Under 11";
			fees = "Rs.600/-";
	}
	else if(age >= 11 && age <= 14)
	{
		ageGroup = "11-14";
		fees = "Rs.400/-";
	}
	else if(age >= 15 && age <= 17)
	{
		ageGroup = "15-17";
		fees = "Rs.200/-";
	}
	else if(age >=18 && age <= 19)
	{
		ageGroup = "18-19";
		fees = "Rs.200/-";
	}
	else
	{
		ageGroup = "Not applicable";
		fees = "-";
	}
	
	 var opt = "Participant Name: "+fullname+"<br>"+
                    "Date of Birth: "+dob+"<br>"+
                    "Skate Type: "+type+"<br>"+
                    "Fees: "+fees+"<br>"+
                    "Age Group: "+ageGroup+"<br>";
    var myWindow1 = window.open("","","height=500,width=500,top=100,left=100");
    myWindow1.document.write(opt);
}