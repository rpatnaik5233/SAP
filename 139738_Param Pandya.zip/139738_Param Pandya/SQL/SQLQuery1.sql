use mydb;
go

--Creating Level table
create table Level (LevelID numeric(3,0) primary key, age varchar(20), Charges numeric(3,0));
go

--Creating SkatingClass table
create table SkatingClass (ClassID numeric(4,0) primary key, LevelID numeric(3,0) NOT NULL, WeekDay varchar(10), 
TimeSlot varchar(30), InstructorName varchar(50), CONSTRAINT fk_sc_li FOREIGN KEY(LevelID) REFERENCES Level (LevelID));
go

--Inserting values in Level table
insert into Level values (101,'Under 11',600);
go
insert into Level values (102,'11-14',400);
go
insert into Level values (103,'15-17',200);
go
insert into Level values (104,'18-19',200);
go
insert into Level values (105,'20-25',200);
go

--Displaying data of Level table
select * from Level;
go

--Inserting values in SkatingClass table
insert into SkatingClass values (1001,101,'Mon','6.00 pm - 7.00 pm','Samantha Hanson');
go
insert into SkatingClass values (1002,101,'Sat','8.00 pm - 9.00 pm','Samantha Hanson');
go
insert into SkatingClass values (1003,104,'Tue','7.00 pm - 8.00 pm','Kristen May');
go
insert into SkatingClass values (1004,105,'Sat','10.00 pm - 11.00 pm','Samantha Hanson');
go
insert into SkatingClass values (1005,105,'Sun','1.00 pm - 2.00 pm','Samantha Hanson');
go
insert into SkatingClass values (1006,103,'Mon','6.00 pm - 7.00 pm','Daniel');
go

--Displaying data of SkatingClass table
select * from SkatingClass;
go

--Q.2)2)
select InstructorName from SkatingClass where WeekDay='Mon' or WeekDay='Tue';
go

--Q.2)3)
create view Schedule_View as 
	select WeekDay, TimeSlot from SkatingClass where InstructorName like '%an%';
go
--Displaying View
select * from Schedule_View;
go


--Q2.4)Procedure
create procedure details @lvlId int as
begin
	begin try
		select sc.TimeSlot, sc.InstructorName, lvl.Charges from SkatingClass sc, Level lvl
		where sc.LevelID = @lvlId and lvl.LevelID = @lvlId and WeekDay='Mon';
	end try
	begin catch
		select ERROR_MESSAGE();
	end catch
end
go

details 101
go