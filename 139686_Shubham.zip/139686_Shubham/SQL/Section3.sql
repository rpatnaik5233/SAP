create table Level (
	levelID int primary key, 
	age varchar(10),
	charges int
);

create table SkatingClass (
	classID int primary key,
	levelID int not null,
	weekday varchar(3),
	timeslot varchar(20),
	instructor varchar(20),
	constraint fk_level foreign key (levelID) references level(levelID)
);


--1
insert into level values('101', 'Under 11', 600);
insert into level values('102', '11-14', 400);
insert into level values('103', '15-17', 200);
insert into level values('104', '18-19', 200);
insert into level values('105', '20-25', 200);

insert into SkatingClass values('1001','101','Mon','6:00pm - 7:00pm','Samantha Hanson');
insert into SkatingClass values('1002','101','Sat','8:00am - 9:00am','Samantha Hanson');
insert into SkatingClass values('1003','104','Tue','7:00pm - 8:00pm','Kristen May');
insert into SkatingClass values('1004','105','Sat','10:00am - 11:00am','Samantha Hanson');
insert into SkatingClass values('1005','105','Sun','1:00pm - 2:00pm','Samantha Hanson');

--2.1
select l.levelID 
from level l, SkatingClass s
where l.levelID not in (select levelID from SkatingClass)
group by l.levelID;


--2.2
select instructor 
from SkatingClass
where weekday in ('Mon','Tue');

--2.3
create view Schedule_View as
select weekday, timeslot
from SkatingClass
where instructor like '%an%';

--2.4
create proc displayInstructor
	@levelID int
as
	select s.timeslot, s.instructor, l.charges
	from SkatingClass s, Level l
	where s.levelID = l.levelID 
	and weekday = 'Mon';

exec displayInstructor 101

--2.5
create nonclustered index IX_timeslot   
on SkatingClass(weekday)
where weekday = 'Mon';  