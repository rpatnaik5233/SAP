function formSubmit() {
    var fname = document.getElementById("firstNameID").value;
    var lname = document.getElementById("lastNameID").value;
    var contact = document.getElementById("contactNumberID").value;
    var email = document.getElementById("emailID").value;
    var dob = document.getElementById("dobID").value;
    var date = new Date();
    var dobDate = new Date(dob);
    var age = date.getFullYear() - dobDate.getFullYear();
    var location = document.getElementById("cityID").value;
    var state;
    if(location == "Chennai") {
        state = "TamilNadu";
    } else if(location == "Mumbai" || location == "Pune") {
        state = "Maharashtra";
    } else if(location == "Bangalore") {
        state = "Karnataka";
    } else {
        state = "No offices in given location";
    }
    var outputStr = "First Name: "+fname+"<br>"+
                    "Last Name: "+lname+"<br>"+
                    "Contact Number: "+contact+"<br>"+
                    "Email Address: "+email+"<br>"+
                    "Date of Birth: "+dob+"<br>"+
                    "Age: "+age+"<br>"+
                    "Current City/Location: "+location+"<br>"+
                    "City State: "+state+"<br>";
    var myWindow = window.open("","","height=500,width=500,top=100,left=100");
    myWindow.document.write(outputStr);
}