CREATE DATABASE M1

use M1
go

-- Question 1) Create the given tables and Insert 5 values in each table

-- Create the Match Table
CREATE TABLE Match (MatchID int PRIMARY KEY, MatchDate date, Stadium varchar(20), Team1 varchar(5), Team2 varchar(5))
go

-- Create the Team Table
CREATE TABLE Team (TeamID varchar(5) PRIMARY KEY, TeamName varchar(20), Coach varchar(20), MatchID int NOT NULL Foreign Key(MatchID) references Match(MatchID), Player varchar(20), Run int)
go

-- Insert Data in Match Table
INSERT INTO Match values (1005,'04/03/2015','Adelaide Oval','IND','PAK')
go
INSERT INTO Match values (1004,'04/04/2015','Eden Gardens','IND','AUS')
go
INSERT INTO Match values (1003,'03/23/2014','Docklands Stadium','AUS','PAK')
go
INSERT INTO Match values (1002,'08/15/2016','Greenfield Stadium','IND','ENG')
go
INSERT INTO Match values (1001,'09/21/2015','Adelaide Oval','IND','PAK')
go

-- Insert Data in Team Table
INSERT INTO Team values ('IND','India','Duncan Fletcher',1005,'Virat Kohli',107)
go
INSERT INTO Team values ('PAK','Pakistan','Tom Moody',1002,'Shahid Afridi',62)
go
INSERT INTO Team values ('AUS','Australia','Ricky Ponting',1005,'Steve Smith',92)
go
INSERT INTO Team values ('SL','Sri Lanka','Ian Chappal',1001,'Angelo Mathews',51)
go
INSERT INTO Team values ('ENG','England','Gary Kirstan',1003,'Eon Morgan',35)
go

Select * from Match
go

Select * from Team
go

-- Question 2) Perform the following
-- 1) Find names of the Team and number of Players who scored more than 100 runs and whose coach is 'Duncan Fletcher'
SELECT TeamName,count(Player) 'No of Players'
FROM Team 
WHERE Coach='Duncan Fletcher' and run>100
GROUP BY TeamName
go

-- 2) Display the count of players who scored more then 50 and less than 100
SELECT count(Player) 'No of Players'
FROM Team
WHERE RUN > 50 AND RUN < 100
go

-- 4) Create a stored procedure which will accept TeamID, MatchID and Display the record of the Score
--		(MatchID, MatchDate, Coach, Player, Run) who scored maximum runs
CREATE PROCEDURE FindData
@team_id varchar(10), @match_id int
AS
BEGIN
	SELECT Match.MatchID, Match.MatchDate, Team.Coach, Team.Player, Team.Run 
	FROM Match INNER JOIN Team 
	ON Match.MatchID = Team.MatchID
	WHERE Team.Run IN (Select max(Team.Run) from Team) AND Team.TeamID = @team_id AND Team.MatchID = @match_id;
END

EXEC FindData 'IND',1005