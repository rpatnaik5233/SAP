//Query to display report
SELECT e.empno,e.ename,r.refname,s.status from employee e,referral r,referralstatus s where e.empno=r.empno AND r.refno=s.refno;