//Display employee name and count of referrals
SELECT e.ename,count(r.refno) AS "Number of Referrals" from employee e,referral r where e.empno=r.empno group by e.ename;