//Insert using sequence
INSERT INTO referral(refno) Values (referencenum.nextval);
UPDATE referral SET refname='&refname',address='&address' ,phoneno=&phoneno ,degree='&degree'  where refno='&refno';