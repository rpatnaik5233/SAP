//Procedure creation and accepting and displaying data using cursor
CREATE OR REPLACE PROCEDURE emp_print(empnum in referral.empno%type)
IS 
	CURSOR cur_val IS SELECT * from referral where empno=empnum;
	r_emp cur_val%rowtype;
	EmployeeNotFound EXCEPTION;
	

BEGIN
	OPEN cur_val;
	LOOP
		FETCH cur_val INTO r_emp;
		IF cur_val%NOTFOUND THEN
			RAISE EmployeeNotFound;
		ELSE 
		
			DBMS_OUTPUT.PUT_LINE(r_emp.refname || ' ' || r_emp.phoneno);
		END IF;
	END LOOP;
	CLOSE cur_val;
EXCEPTION	
WHEN EmployeeNotFound THEN
	DBMS_OUTPUT.PUT_LINE('No employye with given employee id');
	
END emp_print;
/

		