BEGIN 
	emp_print(106);
END;